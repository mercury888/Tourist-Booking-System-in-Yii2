
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
<td colspan="3">
    <h1> Hi <?=$model->name;?> We have received your tour plan. Our expert will contact you as soon as possible</h1>
   
</td>
</tr>
