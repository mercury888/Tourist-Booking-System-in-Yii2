<tr style="margin:10px;background:#e7e6e6;font:600 20px/28px 'neo_sans';font-size: 20px; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
<td colspan="3">
    <div>
        Thank you
    </div>
</td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:600 20px/28px 'neo_sans';font-size: 16px; margin-bottom: 3px; padding: 10px; color:#171515;">
<td colspan="3">
    <div>

        You inquriy has been received. Our expert will reach you back with your provided details.img-responsive
    </div>
   
</td>
</tr>


