
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
<td colspan="3">
    <h1>You have new contact form inquiry from <?=$model->name;?></h1>
   
</td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Subject</td>
    <td colspan="2"><?=$model->subject;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Name</td>
    <td colspan="2"><?=$model->name;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Email</td>
    <td colspan="2"><?=$model->email;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Phone</td>
    <td colspan="2"><?=$model->phone;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Address</td>
    <td colspan="2"><?=$model->address;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Message</td>
    <td colspan="2"><?=$model->body;?></td>
</tr>

