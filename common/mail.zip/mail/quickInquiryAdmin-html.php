
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
<td colspan="2">
    <h1>You have new inquiry from <?=$model->name;?></h1>
</td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td><div>Name</div></td>
    <td colspan="2"><div><?=$model->name;?></div></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td><div>Email</td>
    <td colspan="2"><div><?=$model->email;?></div></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td><div>Phone</td>
    <td colspan="2"><div><?=$model->phone;?></div></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td><div>Address</td>
    <td colspan="2"><div><?=$model->address;?></div></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td><div>Message</td>
    <td colspan="2"><div><?=$model->body;?></div></td>
</tr>

