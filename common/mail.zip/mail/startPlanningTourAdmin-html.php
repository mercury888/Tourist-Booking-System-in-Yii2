
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
<td colspan="3">
    <h1><?=$model->name;?> has started planning tour.</h1>
</td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Email</td>
    <td colspan="2"><?=$model->email;?></td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Phone</td>
    <td colspan="2"><?=$model->phone;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Address</td>
    <td colspan="2"><?=$model->address;?></td>
</tr>



<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Desired Departed Date</td>
    <td colspan="2"><?=$model->desired_depature_date;?></td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Desired Duration</td>
    <td colspan="2"><?=$model->desired_duration;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Adult Guest No</td>
    <td colspan="2"><?=$model->adult_guest_no;?></td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Children No</td>
    <td colspan="2"><?=$model->children_no;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Celebrting Special Occasion</td>
    <td colspan="2"><?=$model->celebrting_special_occasion;?></td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Message</td>
    <td colspan="2"><?=$model->message;?></td>
</tr>



<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>How Did You Hear About Us</td>
    <td colspan="2"><?=$model->how_did_you_hear_about_us;?></td>
</tr>
<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Are You Working With Travel Agent</td>
    <td colspan="2"><?=$model->are_you_working_with_travel_agent;?></td>
</tr>

<tr style="margin:10px;background:#e7e6e6;font:200 16px/24px 'neo_sans'; margin-bottom: 3px; padding: 10px; text-transform: uppercase; color:#171515;">
    <td>Newsletter Signup</td>
    <td colspan="2"><?=$model->newsletter_signup;?></td>
</tr>

