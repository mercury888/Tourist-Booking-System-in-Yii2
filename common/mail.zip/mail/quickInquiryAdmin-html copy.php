
<tr>
<td colspan="3">
    <h1>You have new inquiry from <?=$model->name;?></h1>
</td>
</tr>

<tr>
    <td>Name</td>
    <td colspan="2"><?=$model->name;?></td>
</tr>
<tr>
    <td>Email</td>
    <td colspan="2"><?=$model->email;?></td>
</tr>
<tr>
    <td>Phone</td>
    <td colspan="2"><?=$model->phone;?></td>
</tr>
<tr>
    <td>Address</td>
    <td colspan="2"><?=$model->address;?></td>
</tr>
<tr>
    <td>Message</td>
    <td colspan="2"><?=$model->body;?></td>
</tr>
<tr>

</tr>

